CREATE PROCEDURE dbo.Rep_Village_Collection_Sheet_info
@village_id INT
,@from DATETIME
,@to DATETIME
,@display_in INT
,@branch_id INT
AS BEGIN
	SELECT v.name,
	  MIN(c.[start_date]) AS fisrt_disb_date, 
	  MAX(i.expected_date) AS last_rep_date
	FROM InstallmentSnapshot(@from) AS i
	INNER JOIN dbo.Contracts AS c ON c.id = i.contract_id
	INNER JOIN dbo.Credit AS cr ON cr.id = c.id and cr.disbursed = 1
	INNER JOIN dbo.ActiveLoans_MC(@from, 0, @display_in, @branch_id) AS al ON al.id = c.id
	INNER JOIN dbo.Projects AS j ON j.id = c.project_id
	INNER JOIN dbo.Tiers AS t ON t.id = j.tiers_id
	INNER JOIN dbo.VillagesPersons vp ON vp.person_id = t.id
	INNER JOIN dbo.Villages v ON v.id = vp.village_id
	INNER JOIN dbo.Persons p ON p.id = vp.person_id
	WHERE t.branch_id = @branch_id AND v.id = @village_id
	GROUP BY v.name
END
