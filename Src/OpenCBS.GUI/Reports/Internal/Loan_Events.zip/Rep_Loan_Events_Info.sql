CREATE PROCEDURE Rep_Loan_Events_Info 
	@contract_id INT
AS BEGIN
	SELECT c.contract_code, c.start_date,
	cr.amount, dbo.getEntryFees(@contract_id) AS entry_fees, cr.nb_of_installment,
	u.first_name + SPACE(1) + u.last_name AS loan_officer,
	t.id AS client_id,
	ISNULL(corp.[name], ISNULL(g.[name], p.first_name + SPACE(1) + p.last_name)) AS client_name
	FROM dbo.Contracts AS c
	LEFT JOIN dbo.Credit AS cr ON cr.id = c.id	
	LEFT JOIN dbo.Users AS u ON cr.loanofficer_id = u.id
	LEFT JOIN dbo.Projects AS j ON c.project_id = j.id
	LEFT JOIN dbo.Tiers AS t ON j.tiers_id = t.id
	LEFT JOIN dbo.Persons AS p ON t.id = p.id
	LEFT JOIN dbo.Groups AS g ON t.id = g.id
	LEFT JOIN dbo.Corporates AS corp ON t.id = corp.id
	WHERE c.id = @contract_id
END